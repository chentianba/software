      COMMON /USLIST/ USFULL
      LOGICAL USFULL
*-----------------------------------------------------------------------
*   USFULL  = set .TRUE. if input file to be printed to MZUNIT
*-----------------------------------------------------------------------
